import React from 'react';

export default  
{
  items : [
    {
      cityName : 'İstanbul',
      countryName : 'Turkey'
    },
    {
      cityName : 'Denizli',
      countryName : 'Turkey'
    },
    {
      cityName : 'Konya',
      countryName : 'Turkey'
    },
    {
      cityName : 'Tekirdağ',
      countryName : 'Turkey'
    },
    {
      cityName : 'Izmir',
      countryName : 'Turkey'
    },
    {
      cityName : 'Antalya',
      countryName : 'Turkey'
    }
  ]
};